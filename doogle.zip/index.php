<!DOCTYPE html>
<html lang="id">
<head>
	<title>Doogle</title>

	<meta name="description" content="Mesin pencari khusus untuk menemukan katalog furnitur dan gambar.">
	<meta name="keywords" content="mesin pencari, doogle, katalog furnitur, gambar">
	<meta name="author" content="Zepher Ashe">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" type="image/x-icon" href="assets/images/favicon/favicon.ico">
	<link rel="shortcut icon" type="image/png" href="assets/images/favicon/favicon-32x32.png">
	<link rel="apple-touch-icon" href="assets/images/favicon/apple-touch-icon.png">
	<link rel="android-chrome-icon" type="image/png" href="assets/images/favicon/android-chrome-512x512.png">

	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
    <div class="wrapper indexPage">
        <div class="mainSection">
			<div class="logoContainer">
				<img src="assets/images/doogleLogo.png" title="Logo Situs Doogle" alt="Logo Situs">
			</div>

			<div class="searchContainer">
				<form action="cari.php" method="GET">
					<input class="searchBox" type="text" name="term" autocomplete="off">
					<input class="searchButton" type="submit" value="Cari">
				</form>
			</div>
		</div>
    </div>
</body>
</html>